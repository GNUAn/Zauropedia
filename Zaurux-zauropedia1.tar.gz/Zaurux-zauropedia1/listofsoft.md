List of NECESSARY software that isn't included here:
Disk drivers
GPU drivers(f*ck Nvidia)

List of USEFUL software that isn't included here:
xfce4-panel
xfce4-terminal
cowsay
vrms(RMS)
gcc(or any other compiler collection)
emacs(or any other text editor)
git(or any other version control system)
SQLite(or any other SQL)