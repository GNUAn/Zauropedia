/home is a directory, where user files are stored
